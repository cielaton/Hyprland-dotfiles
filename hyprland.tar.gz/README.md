The Ultimate Hyprland Config (A Desktop Environment Like Experience) for Archcraft and other Linux Distributions.

---

**For Installation Instructions, Visit** :: `https://github.com/archcraft-os/archcraft-hyprland`

---

Note : May not work with **Nvidia** (using proprietary graphics drivers)
More info :: `https://wiki.archlinux.org/title/Sway#Installation`, `https://wiki.archlinux.org/title/wayland#Requirements`

---

If you face any issue setting this up, feel free to ask for help at :: `adi1090x@gmail.com`
Find any bug in the config, Open an issue :: `https://github.com/archcraft-os/archcraft-hyprland/issues`
